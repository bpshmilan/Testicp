



# Practical IBM Cloud Private Workshop


![ICP Logo](./images/logoicp.png)


